# Benchmarking

Performance claims are accepted only with reproducible commands and enough
environment metadata to explain the result. Benchmarking is not a substitute
for correctness parity.

## Safety First

Real-model CPU and CUDA runs can consume most system RAM or VRAM. Prefer hosted
CI and the guarded self-hosted GPU workflow. Before a local GPU run:

1. confirm the intended model size and quantization;
2. inspect device-wide memory use with `nvidia-smi`;
3. stop if existing GPU use exceeds the operator threshold;
4. set conservative GPU budget and token limits;
5. run one process and one sequence first;
6. verify cleanup before increasing load.

The repository's guarded GPU runner uses a 4096 MiB initial-use threshold for
shared-machine validation. Do not weaken that guard to make a benchmark start.

## Compile Benchmarks Without Running

```bash
cargo bench --workspace --no-run --locked
```

This is the normal CI gate. It validates benchmark code without starting a
model workload.

## Runtime Benchmark Command

```bash
cargo run --release --locked -p xrt-cli -- bench \
  --model ./models/model.gguf \
  --prompt "Benchmark prompt" \
  --backends cpu \
  --cache-modes f32,q8,agent_adaptive \
  --max-tokens 64 \
  --repetitions 3 \
  --seed 1 \
  --json
```

For CUDA, build the CLI with the feature and start with one token:

```bash
cargo run --release --locked -p xrt-cli --features cuda -- bench \
  --model ./models/model.gguf \
  --prompt "Hello" \
  --backends cuda \
  --cache-modes f32 \
  --max-tokens 1 \
  --repetitions 1 \
  --concurrency 1 \
  --seed 1 \
  --json
```

The JSON report records requested and active backend, model/architecture,
prompt/output tokens, load/prefill/total times, throughput, process memory, GPU
resource status, cache/scheduler status, transfer deltas, allocation deltas,
and errors.

## Frozen Prompt-Suite Parity

Use `--prompt-suite` for a versioned local admission corpus. The runtime loads
the model once per requested backend, then executes every case in the suite.
Suite runs require concurrency one and add `suite_id`, `case_id`, and the exact
`output_token_ids` to the JSON report. Exact token IDs are deliberately limited
to local single-sequence runs; an external OpenAI-compatible endpoint does not
expose a portable token-ID contract.

```bash
target/release/xrt-cli bench \
  --model /workspace/model/Qwen3.6-27B-Q4_K_S.gguf \
  --prompt-suite benchmark-corpora/text/qwen36-greedy-admission-v1.json \
  --backends cuda-resident \
  --cache-modes f32 \
  --temperature 0 \
  --top-k 1 \
  --top-p 1 \
  --repetition-penalty 1 \
  --seed 424242 \
  --json
```

The Qwen3.6 admission helper runs target-only, scalar-head MTP, tensor-head
MTP, and the retained depth-ten tiled-verifier arm with the same frozen cases.
It then fails unless every repetition is internally deterministic and every
candidate token trace exactly matches the target-only trace:

```bash
scripts/benchmark-qwen36-greedy-admission.sh \
  /workspace/model/Qwen3.6-27B-Q4_K_S.gguf \
  /workspace/profiles/qwen36-greedy-admission \
  1
```

The parity comparator is also independently reusable:

```bash
python3 scripts/compare-bench-token-parity.py baseline.json candidate.json
```

Passing this corpus is evidence for deterministic greedy parity on its pinned
cases only. It does not admit non-greedy speculative sampling, long context,
concurrency, cancellation, recovery, another model hash, or another GPU.

## Qwen3.6 Production-Admission Matrix

Generate the deterministic quality, shared-history, and long-context corpora,
then run the production matrix one phase at a time so a failed gate does not
erase later evidence:

```bash
python3 scripts/generate-qwen36-production-corpora.py
scripts/benchmark-qwen36-production.sh \
  /workspace/model/Qwen3.6-27B-Q4_K_S.gguf \
  /workspace/dflash-model/dflash-draft-3.6-q8_0-rope10m.gguf \
  /workspace/profiles/qwen36-production \
  quality,context,tuned-context,quantized-context,multiturn,sampling,concurrency,cpu
```

The matrix records immutable model, draft, corpus, binary, source-tree, GPU,
CPU, CUDA, and toolchain metadata. The quality and context phases validate
required output text as well as generation success. Candidate greedy runs also
require exact target-token parity. `tuned-context` defaults to the complete
through-16K ladder under its documented memory policy, which includes at least
one point beyond the admitted DFlash profile; set `XRT_TUNED_MAX_CONTEXT` only
to another generated bounded corpus. Because long-prompt causal attention is
expensive, `quantized-context` defaults to the complete through-8K ladder; set
`XRT_QUANTIZED_MAX_CONTEXT=16384` only when the additional runtime and cost are
explicitly intended. Every quantized-cache mode runs both target-only and
DFlash arms, validates the required answer, and records exact greedy token
parity. A capacity failure is not extrapolated into a successful larger
context, and a later size is never needed to establish a smaller candidate's
admission boundary.

This matrix uses `--enable-thinking false` for the fast non-thinking profile.
Thinking-enabled quality must be reported separately; a non-thinking parity
pass proves implementation parity, not task correctness or equivalent model
quality.

Local JSON results report `prompt_tokenize_ms` separately from model execution.
`prefill_ms`, `total_ms`, and `tok_s` remain inference-only for comparison with
older XRT records; `end_to_end_ms` and `end_to_end_tok_s` add one prompt encode.
Use the live OpenAI service harness for authoritative client-observed latency,
because it also includes HTTP, queueing, template rendering, and response work.

The DFlash A/B helper treats its repetition argument as measured repetitions
and prepends one warmup repetition per case by default. Raw JSON retains every
sample for auditability; reported statistics must exclude repetition 1 as
recorded in `measurement-policy.txt`. Set
`XRT_BENCH_WARMUP_REPETITIONS` only when the policy change is documented.

Run the service gate against loopback with an intentionally bounded scheduler:

```bash
env \
  XRT_NGRAM_SPECULATION=0 \
  XRT_QWEN_MTP=1 XRT_QWEN_MTP_MAX_DRAFT_TOKENS=15 \
  XRT_QWEN_MTP_ADAPTIVE_FALLBACK=0 XRT_QWEN_MTP_VOCAB_ROWS=65536 \
  XRT_QWEN_MTP_BATCHED_REBASE=1 XRT_QWEN_MTP_Q6_TENSOR_CORE_HEAD=0 \
  XRT_QWEN_DFLASH_DRAFT_MODEL=/workspace/dflash-model/dflash-draft-3.6-q8_0-rope10m.gguf \
  XRT_CUDA_Q4_K_MARLIN=1 XRT_CUDA_KQUANT_TENSOR_CORE_VERIFY=1 \
  XRT_CUDA_PARALLEL_VERIFY_PROJECTIONS=1 XRT_CUDA_MARLIN_FUSED_EPILOGUES=1 \
  XRT_QWEN_MTP_VERIFY_GRAPH=1 XRT_CUDA_DFLASH_Q8_0_MARLIN=1 \
  XRT_CUDA_DFLASH_PARALLEL_PROJECTIONS=0 \
  XRT_GPU_MEMORY_FRACTION=0.94 XRT_GPU_RESERVED_MB=1024 XRT_GPU_KV_FRACTION=0.55 \
  target/release/xrt-server \
  --model /workspace/model/Qwen3.6-27B-Q4_K_S.gguf \
  --backend cuda-resident \
  --host 127.0.0.1 --port 18080 \
  --max-active-sequences 1 --max-queued-sequences 4 \
  > /workspace/profiles/qwen36-production/api/server.log 2>&1 &
server_pid=$!

python3 scripts/benchmark-xrt-openai-service.py \
  --base-url http://127.0.0.1:18080 \
  --server-pid "$server_pid" \
  --model-path /workspace/model/Qwen3.6-27B-Q4_K_S.gguf \
  --long-context-suite benchmark-corpora/text/qwen36-production-v1/context-08192.json \
  --long-context-expected benchmark-corpora/text/qwen36-production-v1/context-08192.expected.json \
  --timeout 1200 \
  --soak-requests 100 \
  --output /workspace/profiles/qwen36-production/api/service.json

kill "$server_pid"
wait "$server_pid" || true
```

This verifies both completion routes, streaming terminal reasons, direct and
nested thinking controls, thinking-enabled arithmetic, multi-turn recall,
bounded concurrency, queue-overload backpressure, streaming cancellation,
invalid input, scheduler cleanup, soak latency and memory growth, plus unload,
unavailable behavior, reload, and post-reload inference.

## Portable vs Native CPU Builds

Release and CI builds are portable and do not set `target-cpu=native`. Local
microbenchmarks may opt in explicitly.

PowerShell:

```powershell
$env:RUSTFLAGS = '-C target-cpu=native'
cargo bench --workspace --locked
Remove-Item Env:RUSTFLAGS
```

Bash:

```bash
RUSTFLAGS='-C target-cpu=native' cargo bench --workspace --locked
```

Never compare a native local build to a portable release build without labeling
the difference.

## Required Result Metadata

Every published result must include:

- xeno-rt commit and dirty-tree state;
- exact command and environment overrides;
- model repository/file/hash, architecture, and quantization;
- CPU model, core/thread policy, RAM, OS, and power mode;
- GPU model, driver, visible VRAM, and CUDA path when applicable;
- build profile and `RUSTFLAGS`;
- prompt tokens, generated tokens, seed, cache mode, and concurrency;
- warmup/repetition count and raw JSON output;
- correctness/parity gate used before timing.

Report median and distribution, not only the fastest sample. Keep load time,
prefill latency, time to first token, decode throughput, and peak memory as
separate measurements.

## Regression Rule

A performance-sensitive pull request must compare the same command on the base
and head commits. Correctness, API compatibility, CPU fallback, and memory
safety take precedence over a throughput improvement.
