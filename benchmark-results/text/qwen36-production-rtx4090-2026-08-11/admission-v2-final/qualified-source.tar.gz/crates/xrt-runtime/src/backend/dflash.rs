//! Experimental Qwen3.6 DFlash drafter admission and resident weights.
//!
//! The target model remains the ordinary XRT Qwen3.6 runtime. This module owns
//! only the auxiliary block drafter selected with
//! `XRT_QWEN_DFLASH_DRAFT_MODEL`; it does not alter GGUF or public API
//! contracts when the opt-in is absent.

use super::*;
use std::{path::PathBuf, sync::Arc};

const DFLASH_ARCHITECTURE: &str = "qwen35-dflash-draft";
const DFLASH_TARGET_LAYER_IDS: [usize; 5] = [1, 16, 31, 46, 61];
const DFLASH_DRAFT_MODEL_ENV: &str = "XRT_QWEN_DFLASH_DRAFT_MODEL";
const DFLASH_CONTEXT_ENV: &str = "XRT_QWEN_DFLASH_CONTEXT";
const DFLASH_CONTEXT_DEFAULT: usize = 2_048;
const DFLASH_CONTEXT_MAX: usize = 4_096;

#[derive(Debug, Clone, PartialEq)]
pub(super) struct DFlashDraftConfig {
    pub(super) embedding_length: usize,
    pub(super) block_count: usize,
    pub(super) feed_forward_length: usize,
    pub(super) attention_head_count: usize,
    pub(super) attention_head_count_kv: usize,
    pub(super) head_dim: usize,
    pub(super) vocab_size: usize,
    pub(super) rms_norm_eps: f32,
    pub(super) rope_freq_base: f32,
    pub(super) block_size: usize,
    pub(super) mask_token_id: u32,
    pub(super) target_layer_ids: Vec<usize>,
}

impl DFlashDraftConfig {
    pub(super) fn context_capacity_from_env() -> usize {
        env::var(DFLASH_CONTEXT_ENV)
            .ok()
            .and_then(|value| value.parse::<usize>().ok())
            .unwrap_or(DFLASH_CONTEXT_DEFAULT)
            .clamp(16, DFLASH_CONTEXT_MAX)
    }

    fn required_usize(gguf: &GgufFile, suffix: &str) -> Result<usize> {
        let key = format!("{DFLASH_ARCHITECTURE}.{suffix}");
        gguf.metadata_usize(&key).ok_or_else(|| {
            XrtError::InvalidMetadata(format!(
                "DFlash draft GGUF is missing required metadata `{key}`"
            ))
        })
    }

    fn required_f32(gguf: &GgufFile, suffix: &str) -> Result<f32> {
        let key = format!("{DFLASH_ARCHITECTURE}.{suffix}");
        gguf.metadata_f32(&key).ok_or_else(|| {
            XrtError::InvalidMetadata(format!(
                "DFlash draft GGUF is missing required metadata `{key}`"
            ))
        })
    }

    pub(super) fn from_gguf(gguf: &GgufFile, target: &LlamaConfig) -> Result<Self> {
        let architecture = gguf
            .metadata_string("general.architecture")
            .ok_or_else(|| {
                XrtError::InvalidMetadata(
                    "DFlash draft GGUF is missing `general.architecture`".to_string(),
                )
            })?;
        if architecture != DFLASH_ARCHITECTURE {
            return Err(XrtError::Unsupported(format!(
                "DFlash draft architecture `{architecture}` is not the admitted `{DFLASH_ARCHITECTURE}` contract"
            )));
        }

        let n_target_layers = Self::required_usize(gguf, "dflash.n_target_layers")?;
        let target_layer_ids = gguf
            .metadata_array(&format!("{DFLASH_ARCHITECTURE}.dflash.target_layer_ids"))
            .and_then(|values| values.as_u32_vec())
            .map(|values| values.into_iter().map(|value| value as usize).collect())
            .unwrap_or_else(|| DFLASH_TARGET_LAYER_IDS.to_vec());
        if target_layer_ids.len() != n_target_layers {
            return Err(XrtError::InvalidMetadata(format!(
                "DFlash target-layer id count {} does not match declared count {n_target_layers}",
                target_layer_ids.len()
            )));
        }

        let mask_token_id = u32::try_from(Self::required_usize(gguf, "dflash.mask_token_id")?)
            .map_err(|_| {
                XrtError::InvalidMetadata("DFlash mask token id does not fit u32".to_string())
            })?;
        let config = Self {
            embedding_length: Self::required_usize(gguf, "embedding_length")?,
            block_count: Self::required_usize(gguf, "block_count")?,
            feed_forward_length: Self::required_usize(gguf, "feed_forward_length")?,
            attention_head_count: Self::required_usize(gguf, "attention.head_count")?,
            attention_head_count_kv: Self::required_usize(gguf, "attention.head_count_kv")?,
            head_dim: Self::required_usize(gguf, "attention.key_length")?,
            vocab_size: Self::required_usize(gguf, "vocab_size")?,
            rms_norm_eps: Self::required_f32(gguf, "attention.layer_norm_rms_epsilon")?,
            rope_freq_base: Self::required_f32(gguf, "rope.freq_base")?,
            block_size: Self::required_usize(gguf, "dflash.block_size")?,
            mask_token_id,
            target_layer_ids,
        };
        config.validate_target(target)?;
        Ok(config)
    }

    fn validate_target(&self, target: &LlamaConfig) -> Result<()> {
        if !target.is_qwen35_family() || !target.is_hybrid() || target.is_moe() {
            return Err(XrtError::Unsupported(
                "the admitted DFlash draft path requires a dense Qwen3.6 hybrid target".to_string(),
            ));
        }
        // DFlash is an auxiliary transformer, not a copy of the target
        // attention geometry. Its 32 query / 8 KV heads at width 128 are part
        // of the admitted drafter contract below; only the shared hidden and
        // vocabulary spaces must agree with the target.
        if self.embedding_length != target.embedding_length || self.vocab_size != target.vocab_size
        {
            return Err(XrtError::Unsupported(format!(
                "DFlash drafter spaces do not match the target: draft dim/vocab={}/{}, target={}/{}",
                self.embedding_length,
                self.vocab_size,
                target.embedding_length,
                target.vocab_size,
            )));
        }
        if self.block_count != 5
            || self.block_size != 16
            || self.target_layer_ids != DFLASH_TARGET_LAYER_IDS
            || self.feed_forward_length != 17_408
            || self.embedding_length != 5_120
            || self.attention_head_count != 32
            || self.attention_head_count_kv != 8
            || self.head_dim != 128
        {
            return Err(XrtError::Unsupported(format!(
                "DFlash drafter does not match the admitted Qwen3.6-27B block-16 contract: {self:?}"
            )));
        }
        if self.mask_token_id as usize >= self.vocab_size {
            return Err(XrtError::InvalidMetadata(format!(
                "DFlash mask token {} exceeds vocabulary size {}",
                self.mask_token_id, self.vocab_size
            )));
        }
        if !self.rms_norm_eps.is_finite()
            || self.rms_norm_eps <= 0.0
            || !self.rope_freq_base.is_finite()
            || self.rope_freq_base <= 0.0
        {
            return Err(XrtError::InvalidMetadata(
                "DFlash normalization/RoPE metadata must be finite and positive".to_string(),
            ));
        }
        if self.rope_freq_base != target.rope_freq_base {
            return Err(XrtError::Unsupported(format!(
                "DFlash RoPE base {} does not match target RoPE base {}; reconvert the draft artifact from the matching model config",
                self.rope_freq_base, target.rope_freq_base
            )));
        }
        Ok(())
    }
}

#[derive(Debug)]
pub(super) struct CudaQwen35DFlashLayerCache {
    pub(super) key: CudaF32Buffer,
    pub(super) value: CudaF32Buffer,
}

#[derive(Debug)]
pub(super) struct CudaQwen35DFlashState {
    pub(super) capacity: usize,
    pub(super) len: usize,
    pub(super) projection_streams: Vec<CudaExecutionStream>,
    pub(super) feature_rows: CudaF32Buffer,
    pub(super) projected_rows: CudaF32Buffer,
    pub(super) normed_rows: CudaF32Buffer,
    pub(super) k_update: CudaF32Buffer,
    pub(super) v_update: CudaF32Buffer,
    pub(super) cache: Vec<CudaQwen35DFlashLayerCache>,
    pub(super) noise_a: CudaF32Buffer,
    pub(super) noise_b: CudaF32Buffer,
    pub(super) noise_normed: CudaF32Buffer,
    pub(super) query: CudaF32Buffer,
    pub(super) noise_key: CudaF32Buffer,
    pub(super) noise_value: CudaF32Buffer,
    pub(super) attention: CudaF32Buffer,
    pub(super) ffn_gate: CudaF32Buffer,
    pub(super) ffn_up: CudaF32Buffer,
    pub(super) hidden_temp: CudaF32Buffer,
    pub(super) logits: CudaF32Buffer,
    pub(super) argmax_indices: CudaF32Buffer,
}

impl CudaQwen35DFlashState {
    pub(super) fn device_bytes(config: &DFlashDraftConfig, capacity: usize) -> Result<u64> {
        let rows = config.block_size;
        let dim = config.embedding_length;
        let q_width = config
            .attention_head_count
            .checked_mul(config.head_dim)
            .ok_or_else(|| XrtError::Shape("DFlash query width overflowed".to_string()))?;
        let kv_width = config
            .attention_head_count_kv
            .checked_mul(config.head_dim)
            .ok_or_else(|| XrtError::Shape("DFlash KV width overflowed".to_string()))?;
        let feature_width = dim
            .checked_mul(config.target_layer_ids.len())
            .ok_or_else(|| XrtError::Shape("DFlash feature width overflowed".to_string()))?;
        let per_row = feature_width
            .checked_add(dim.checked_mul(5).ok_or_else(|| {
                XrtError::Shape("DFlash hidden scratch width overflowed".to_string())
            })?)
            .and_then(|value| value.checked_add(q_width.checked_mul(2)?))
            .and_then(|value| value.checked_add(kv_width.checked_mul(4)?))
            .and_then(|value| value.checked_add(config.feed_forward_length.checked_mul(2)?))
            .and_then(|value| value.checked_add(config.vocab_size))
            .and_then(|value| value.checked_add(1))
            .ok_or_else(|| XrtError::Shape("DFlash row scratch size overflowed".to_string()))?;
        let cache_elements = config
            .block_count
            .checked_mul(2)
            .and_then(|value| value.checked_mul(capacity))
            .and_then(|value| value.checked_mul(kv_width))
            .ok_or_else(|| XrtError::Shape("DFlash cache size overflowed".to_string()))?;
        per_row
            .checked_mul(rows)
            .and_then(|value| value.checked_add(cache_elements))
            .and_then(|value| value.checked_mul(std::mem::size_of::<f32>()))
            .and_then(|value| u64::try_from(value).ok())
            .ok_or_else(|| XrtError::Shape("DFlash device byte count overflowed".to_string()))
    }

    pub(super) fn allocate(
        device: &CudaDevice,
        config: &DFlashDraftConfig,
        capacity: usize,
    ) -> Result<Self> {
        let rows = config.block_size;
        let dim = config.embedding_length;
        let q_width = config.attention_head_count * config.head_dim;
        let kv_width = config.attention_head_count_kv * config.head_dim;
        let feature_width = dim * config.target_layer_ids.len();
        let sized = |width: usize, label: &str| {
            rows.checked_mul(width)
                .ok_or_else(|| XrtError::Shape(format!("DFlash {label} size overflowed")))
        };
        let mut cache = Vec::with_capacity(config.block_count);
        for _ in 0..config.block_count {
            let elements = capacity
                .checked_mul(kv_width)
                .ok_or_else(|| XrtError::Shape("DFlash layer cache size overflowed".to_string()))?;
            cache.push(CudaQwen35DFlashLayerCache {
                key: device.zeros_f32(elements)?,
                value: device.zeros_f32(elements)?,
            });
        }
        Ok(Self {
            capacity,
            len: 0,
            projection_streams: (0..2)
                .map(|_| device.create_execution_stream())
                .collect::<Result<Vec<_>>>()?,
            feature_rows: device.zeros_f32(sized(feature_width, "feature rows")?)?,
            projected_rows: device.zeros_f32(sized(dim, "projected rows")?)?,
            normed_rows: device.zeros_f32(sized(dim, "normalized rows")?)?,
            k_update: device.zeros_f32(sized(kv_width, "key update")?)?,
            v_update: device.zeros_f32(sized(kv_width, "value update")?)?,
            cache,
            noise_a: device.zeros_f32(sized(dim, "noise A")?)?,
            noise_b: device.zeros_f32(sized(dim, "noise B")?)?,
            noise_normed: device.zeros_f32(sized(dim, "noise norm")?)?,
            query: device.zeros_f32(sized(q_width, "query")?)?,
            noise_key: device.zeros_f32(sized(kv_width, "noise key")?)?,
            noise_value: device.zeros_f32(sized(kv_width, "noise value")?)?,
            attention: device.zeros_f32(sized(q_width, "attention")?)?,
            ffn_gate: device.zeros_f32(sized(config.feed_forward_length, "FFN gate")?)?,
            ffn_up: device.zeros_f32(sized(config.feed_forward_length, "FFN up")?)?,
            hidden_temp: device.zeros_f32(sized(dim, "hidden temporary")?)?,
            logits: device.zeros_f32(sized(config.vocab_size, "logits")?)?,
            argmax_indices: device.zeros_f32(rows)?,
        })
    }

    pub(super) fn truncate(&mut self, len: usize) {
        self.len = self.len.min(len);
    }

    pub(super) fn clear(&mut self) {
        self.len = 0;
    }
}

pub(super) struct DFlashDraftPlan {
    pub(super) path: PathBuf,
    pub(super) gguf: Arc<GgufFile>,
    pub(super) config: DFlashDraftConfig,
    pub(super) resident_bytes: u64,
}

impl DFlashDraftPlan {
    pub(super) fn from_env(target: &LlamaConfig) -> Result<Option<Self>> {
        let Some(path) = env::var_os(DFLASH_DRAFT_MODEL_ENV)
            .filter(|value| !value.is_empty())
            .map(PathBuf::from)
        else {
            return Ok(None);
        };
        let gguf = Arc::new(GgufFile::open(&path).map_err(|error| {
            XrtError::Runtime(format!(
                "failed to open DFlash draft GGUF `{}`: {error}",
                path.display()
            ))
        })?);
        let config = DFlashDraftConfig::from_gguf(&gguf, target)?;
        validate_tensor_contract(&gguf, &config)?;
        let resident_bytes = resident_weight_bytes(&gguf)?;
        Ok(Some(Self {
            path,
            gguf,
            config,
            resident_bytes,
        }))
    }
}

pub(super) struct ResidentQwen35DFlashLayerWeights {
    pub(super) attn_norm: GpuF32Tensor,
    pub(super) attn_q: ResidentQuantMatrix,
    pub(super) attn_k: ResidentQuantMatrix,
    pub(super) attn_v: ResidentQuantMatrix,
    pub(super) attn_output: ResidentQuantMatrix,
    pub(super) attn_q_norm: GpuF32Tensor,
    pub(super) attn_k_norm: GpuF32Tensor,
    pub(super) ffn_norm: GpuF32Tensor,
    pub(super) ffn_gate: ResidentQuantMatrix,
    pub(super) ffn_up: ResidentQuantMatrix,
    pub(super) ffn_down: ResidentQuantMatrix,
    pub(super) sliding_window: bool,
}

pub(super) struct ResidentQwen35DFlashWeights {
    pub(super) config: DFlashDraftConfig,
    pub(super) feature_projection: ResidentQuantMatrix,
    pub(super) hidden_norm: GpuF32Tensor,
    pub(super) output_norm: GpuF32Tensor,
    pub(super) layers: Vec<ResidentQwen35DFlashLayerWeights>,
}

impl ResidentQwen35DFlashWeights {
    pub(super) fn load(device: &CudaDevice, plan: &DFlashDraftPlan) -> Result<Self> {
        let source = GgufResidentTensorSource::new(&plan.gguf);
        let mut layers = Vec::with_capacity(plan.config.block_count);
        for layer in 0..plan.config.block_count {
            layers.push(ResidentQwen35DFlashLayerWeights {
                attn_norm: upload_resident_f32_tensor(
                    device,
                    &source,
                    &format!("blk.{layer}.attn_norm.weight"),
                )?,
                attn_q: ResidentQuantMatrix::upload_dflash(
                    device,
                    &source,
                    &format!("blk.{layer}.attn_q.weight"),
                )?,
                attn_k: ResidentQuantMatrix::upload_dflash(
                    device,
                    &source,
                    &format!("blk.{layer}.attn_k.weight"),
                )?,
                attn_v: ResidentQuantMatrix::upload_dflash(
                    device,
                    &source,
                    &format!("blk.{layer}.attn_v.weight"),
                )?,
                attn_output: ResidentQuantMatrix::upload_dflash(
                    device,
                    &source,
                    &format!("blk.{layer}.attn_output.weight"),
                )?,
                attn_q_norm: upload_resident_f32_tensor(
                    device,
                    &source,
                    &format!("blk.{layer}.attn_q_norm.weight"),
                )?,
                attn_k_norm: upload_resident_f32_tensor(
                    device,
                    &source,
                    &format!("blk.{layer}.attn_k_norm.weight"),
                )?,
                ffn_norm: upload_resident_f32_tensor(
                    device,
                    &source,
                    &format!("blk.{layer}.ffn_norm.weight"),
                )?,
                ffn_gate: ResidentQuantMatrix::upload_dflash(
                    device,
                    &source,
                    &format!("blk.{layer}.ffn_gate.weight"),
                )?,
                ffn_up: ResidentQuantMatrix::upload_dflash(
                    device,
                    &source,
                    &format!("blk.{layer}.ffn_up.weight"),
                )?,
                ffn_down: ResidentQuantMatrix::upload_dflash(
                    device,
                    &source,
                    &format!("blk.{layer}.ffn_down.weight"),
                )?,
                sliding_window: layer + 1 < plan.config.block_count,
            });
        }
        Ok(Self {
            config: plan.config.clone(),
            feature_projection: ResidentQuantMatrix::upload_dflash(
                device,
                &source,
                "dflash.fc.weight",
            )?,
            hidden_norm: upload_resident_f32_tensor(device, &source, "dflash.hidden_norm.weight")?,
            output_norm: upload_resident_f32_tensor(device, &source, "output_norm.weight")?,
            layers,
        })
    }
}

fn validate_tensor_contract(gguf: &GgufFile, config: &DFlashDraftConfig) -> Result<()> {
    let source = GgufResidentTensorSource::new(gguf);
    let dim = config.embedding_length;
    let feature_width = dim
        .checked_mul(config.target_layer_ids.len())
        .ok_or_else(|| XrtError::Shape("DFlash feature width overflowed".to_string()))?;
    let q_width = config
        .attention_head_count
        .checked_mul(config.head_dim)
        .ok_or_else(|| XrtError::Shape("DFlash query width overflowed".to_string()))?;
    let kv_width = config
        .attention_head_count_kv
        .checked_mul(config.head_dim)
        .ok_or_else(|| XrtError::Shape("DFlash KV width overflowed".to_string()))?;

    require_linear(&source, "dflash.fc.weight", dim, feature_width)?;
    for name in ["dflash.hidden_norm.weight", "output_norm.weight"] {
        require_vector(&source, name, dim)?;
    }
    for layer in 0..config.block_count {
        for name in ["attn_norm", "ffn_norm"] {
            require_vector(&source, &format!("blk.{layer}.{name}.weight"), dim)?;
        }
        for name in ["attn_q_norm", "attn_k_norm"] {
            require_vector(
                &source,
                &format!("blk.{layer}.{name}.weight"),
                config.head_dim,
            )?;
        }
        for (name, rows, cols) in [
            ("attn_q", q_width, dim),
            ("attn_k", kv_width, dim),
            ("attn_v", kv_width, dim),
            ("attn_output", dim, q_width),
            ("ffn_gate", config.feed_forward_length, dim),
            ("ffn_up", config.feed_forward_length, dim),
            ("ffn_down", dim, config.feed_forward_length),
        ] {
            require_linear(&source, &format!("blk.{layer}.{name}.weight"), rows, cols)?;
        }
    }
    Ok(())
}

fn require_vector(source: &impl ResidentTensorSource, name: &str, expected: usize) -> Result<()> {
    let info = source.require_tensor(name)?;
    if !is_supported_resident_float_tensor(&info) || info.numel != expected {
        return Err(XrtError::InvalidTensor(format!(
            "DFlash tensor `{name}` must be a supported {expected}-element float vector, found dtype={:?} storage={:?} shape={}x{}",
            info.dtype, info.storage, info.rows, info.cols
        )));
    }
    Ok(())
}

fn require_linear(
    source: &impl ResidentTensorSource,
    name: &str,
    rows: usize,
    cols: usize,
) -> Result<()> {
    let info = source.require_tensor(name)?;
    if info.storage != ResidentTensorStorage::Dense
        || info.dtype != DType::Q8_0
        || info.rows != rows
        || info.cols != cols
    {
        return Err(XrtError::InvalidTensor(format!(
            "DFlash tensor `{name}` must be a dense Q8_0 {rows}x{cols} linear, found dtype={:?} storage={:?} shape={}x{}",
            info.dtype, info.storage, info.rows, info.cols
        )));
    }
    Ok(())
}

fn resident_weight_bytes(gguf: &GgufFile) -> Result<u64> {
    let source = GgufResidentTensorSource::new(gguf);
    source
        .tensor_infos()
        .into_iter()
        .try_fold(0u64, |total, info| {
            let bytes = if is_supported_resident_float_tensor(&info) {
                cuda_resident_f32_tensor_bytes(&info)?
            } else {
                cuda_matrix_resident_tensor_bytes(&info)?
            };
            total.checked_add(bytes).ok_or_else(|| {
                XrtError::Runtime("DFlash resident weight byte count overflowed".to_string())
            })
        })
}

impl CudaResidentBackend {
    fn dflash_parallel_projections_enabled() -> bool {
        env::var("XRT_CUDA_DFLASH_PARALLEL_PROJECTIONS").is_ok_and(|value| {
            let value = value.trim();
            !value.is_empty()
                && value != "0"
                && !value.eq_ignore_ascii_case("false")
                && !value.eq_ignore_ascii_case("off")
        })
    }

    fn dflash_parallel_projection_supported(matrix: &ResidentQuantMatrix) -> bool {
        matches!(matrix, ResidentQuantMatrix::Q8_0(matrix) if matrix.uses_marlin_layout())
    }

    fn trace_dflash_buffer(
        &self,
        label: &str,
        buffer: &CudaF32Buffer,
        elements: usize,
    ) -> Result<()> {
        if env::var_os("XRT_QWEN_DFLASH_TRACE").is_none() {
            return Ok(());
        }
        let values = self.device.download_f32(buffer)?;
        let values = &values[..elements.min(values.len())];
        let first = values.iter().take(8).copied().collect::<Vec<_>>();
        let sum = values.iter().map(|&value| value as f64).sum::<f64>();
        let l2 = values
            .iter()
            .map(|&value| (value as f64) * (value as f64))
            .sum::<f64>()
            .sqrt();
        let max_abs = values
            .iter()
            .map(|value| value.abs())
            .fold(0.0f32, f32::max);
        tracing::warn!(
            target: "xrt_runtime::dflash",
            label,
            elements = values.len(),
            sum,
            l2,
            max_abs,
            first = ?first,
            "DFlash parity trace"
        );
        Ok(())
    }

    fn dflash_q8_prefix_matmul(
        &self,
        matrix: &ResidentQuantMatrix,
        input: &CudaF32Buffer,
        rows: usize,
        output: &mut CudaF32Buffer,
    ) -> Result<()> {
        self.dflash_q8_prefix_matmul_on_stream(matrix, input, rows, output, None)
    }

    fn dflash_q8_prefix_matmul_on_stream(
        &self,
        matrix: &ResidentQuantMatrix,
        input: &CudaF32Buffer,
        rows: usize,
        output: &mut CudaF32Buffer,
        stream: Option<&CudaExecutionStream>,
    ) -> Result<()> {
        let ResidentQuantMatrix::Q8_0(matrix) = matrix else {
            return Err(XrtError::Unsupported(format!(
                "the admitted DFlash execution path requires Q8_0 linears, found {}",
                matrix.graph_kind()
            )));
        };
        let profile = env::var_os("XRT_QWEN_DFLASH_PROFILE").is_some();
        if profile {
            self.device.synchronize()?;
        }
        let started = profile.then(std::time::Instant::now);
        let result = self
            .device
            .dflash_matmul_q8_0_batch16_device_prefix_into_on_stream(
                matrix, input, rows, output, stream,
            );
        if profile {
            self.device.synchronize()?;
            tracing::warn!(
                target: "xrt_runtime::dflash",
                weight_rows = matrix.rows(),
                weight_cols = matrix.cols(),
                batch_rows = rows,
                marlin = matrix.uses_marlin_layout(),
                elapsed_micros = started.expect("profile timer exists").elapsed().as_micros(),
                "DFlash projection profile"
            );
        }
        result
    }

    pub(super) fn capture_qwen35_dflash_target_layer(
        &self,
        weights: &ResidentQwen35DFlashWeights,
        state: &mut CudaQwen35DFlashState,
        layer_output: &CudaF32Buffer,
        rows: usize,
        target_layer: usize,
    ) -> Result<()> {
        let Some(capture_index) = weights
            .config
            .target_layer_ids
            .iter()
            .position(|&layer| layer == target_layer)
        else {
            return Ok(());
        };
        self.device.dflash_capture_features_device(
            layer_output,
            &mut state.feature_rows,
            rows,
            weights.config.embedding_length,
            weights.config.embedding_length * weights.config.target_layer_ids.len(),
            capture_index,
        )
    }

    pub(super) fn update_qwen35_dflash_target_cache(
        &self,
        weights: &ResidentQwen35DFlashWeights,
        state: &mut CudaQwen35DFlashState,
        start_position: usize,
        rows: usize,
    ) -> Result<()> {
        if rows == 0 || rows > weights.config.block_size {
            return Err(XrtError::Shape(format!(
                "DFlash target-cache update requires 1..={} rows, found {rows}",
                weights.config.block_size
            )));
        }
        if state.len > start_position {
            state.truncate(start_position);
        }
        if state.len != start_position {
            return Err(XrtError::Runtime(format!(
                "DFlash target-cache update expected position {}, found {}",
                state.len, start_position
            )));
        }
        let config = &weights.config;
        if start_position == 0 {
            self.trace_dflash_buffer(
                "captured_target_features",
                &state.feature_rows,
                rows * config.embedding_length * config.target_layer_ids.len(),
            )?;
        }
        self.dflash_q8_prefix_matmul(
            &weights.feature_projection,
            &state.feature_rows,
            rows,
            &mut state.projected_rows,
        )?;
        self.device.rmsnorm_device_prefix_into(
            &state.projected_rows,
            weights.hidden_norm.buffer(),
            rows,
            config.embedding_length,
            config.rms_norm_eps,
            &mut state.normed_rows,
        )?;
        if start_position == 0 {
            self.trace_dflash_buffer(
                "fused_target_features",
                &state.normed_rows,
                rows * config.embedding_length,
            )?;
        }
        for (layer, cache) in weights.layers.iter().zip(state.cache.iter_mut()) {
            // Qwen3.6 DFlash has context_kv_layer_norm=false: the fused target
            // feature feeds each layer's context K/V projections directly.
            // `attn_norm` belongs only to that layer's noise-block input.
            let parallel = Self::dflash_parallel_projections_enabled()
                && Self::dflash_parallel_projection_supported(&layer.attn_k)
                && Self::dflash_parallel_projection_supported(&layer.attn_v);
            if parallel {
                let dependency = self.device.record_event()?;
                state.projection_streams[0].wait_for_event(&dependency)?;
                self.dflash_q8_prefix_matmul_on_stream(
                    &layer.attn_v,
                    &state.normed_rows,
                    rows,
                    &mut state.v_update,
                    Some(&state.projection_streams[0]),
                )?;
                self.dflash_q8_prefix_matmul(
                    &layer.attn_k,
                    &state.normed_rows,
                    rows,
                    &mut state.k_update,
                )?;
                let completion = state.projection_streams[0].record_event()?;
                self.device.wait_for_event(&completion)?;
            } else {
                self.dflash_q8_prefix_matmul(
                    &layer.attn_k,
                    &state.normed_rows,
                    rows,
                    &mut state.k_update,
                )?;
                self.dflash_q8_prefix_matmul(
                    &layer.attn_v,
                    &state.normed_rows,
                    rows,
                    &mut state.v_update,
                )?;
            }
            self.device.dflash_norm_rope_device(
                &mut state.k_update,
                layer.attn_k_norm.buffer(),
                rows,
                config.attention_head_count_kv,
                config.head_dim,
                start_position,
                config.head_dim,
                config.rms_norm_eps,
                config.rope_freq_base,
            )?;
            let kv_width = config.attention_head_count_kv * config.head_dim;
            self.device.dflash_store_ring_rows_device(
                &state.k_update,
                &mut cache.key,
                rows,
                kv_width,
                start_position,
                state.capacity,
            )?;
            self.device.dflash_store_ring_rows_device(
                &state.v_update,
                &mut cache.value,
                rows,
                kv_width,
                start_position,
                state.capacity,
            )?;
        }
        state.len = start_position.saturating_add(rows);
        Ok(())
    }

    pub(super) fn draft_qwen35_dflash_greedy(
        &self,
        weights: &ResidentQwen35DFlashWeights,
        output_weights: &ResidentQ8_0ProbeWeights,
        next_token_id: u32,
        max_draft_tokens: usize,
        state: &mut CudaQwen35DFlashState,
    ) -> Result<Vec<u32>> {
        let config = &weights.config;
        if next_token_id as usize >= config.vocab_size {
            return Err(XrtError::Model(format!(
                "DFlash boundary token {next_token_id} exceeds vocabulary size {}",
                config.vocab_size
            )));
        }
        let rows = config.block_size;
        let mut token_ids = vec![config.mask_token_id; rows];
        token_ids[0] = next_token_id;
        self.embed_probe_tokens_into(output_weights, &token_ids, &mut state.noise_a)?;
        self.trace_dflash_buffer(
            "noise_embedding",
            &state.noise_a,
            rows * config.embedding_length,
        )?;

        let context_rows = state.len.min(state.capacity);
        let full_context_start = state.len.saturating_sub(context_rows);
        let mut input_is_a = true;
        for (layer_index, (layer, cache)) in
            weights.layers.iter().zip(state.cache.iter()).enumerate()
        {
            let (input, output) = if input_is_a {
                (&state.noise_a, &mut state.noise_b)
            } else {
                (&state.noise_b, &mut state.noise_a)
            };
            self.device.rmsnorm_device_into(
                input,
                layer.attn_norm.buffer(),
                rows,
                config.embedding_length,
                config.rms_norm_eps,
                &mut state.noise_normed,
            )?;
            let parallel_attention = Self::dflash_parallel_projections_enabled()
                && [&layer.attn_q, &layer.attn_k, &layer.attn_v]
                    .into_iter()
                    .all(Self::dflash_parallel_projection_supported);
            if parallel_attention {
                let dependency = self.device.record_event()?;
                for stream in &state.projection_streams {
                    stream.wait_for_event(&dependency)?;
                }
                self.dflash_q8_prefix_matmul_on_stream(
                    &layer.attn_k,
                    &state.noise_normed,
                    rows,
                    &mut state.noise_key,
                    Some(&state.projection_streams[0]),
                )?;
                self.dflash_q8_prefix_matmul_on_stream(
                    &layer.attn_v,
                    &state.noise_normed,
                    rows,
                    &mut state.noise_value,
                    Some(&state.projection_streams[1]),
                )?;
                self.dflash_q8_prefix_matmul(
                    &layer.attn_q,
                    &state.noise_normed,
                    rows,
                    &mut state.query,
                )?;
                for stream in &state.projection_streams {
                    let completion = stream.record_event()?;
                    self.device.wait_for_event(&completion)?;
                }
            } else {
                self.dflash_q8_prefix_matmul(
                    &layer.attn_q,
                    &state.noise_normed,
                    rows,
                    &mut state.query,
                )?;
                self.dflash_q8_prefix_matmul(
                    &layer.attn_k,
                    &state.noise_normed,
                    rows,
                    &mut state.noise_key,
                )?;
                self.dflash_q8_prefix_matmul(
                    &layer.attn_v,
                    &state.noise_normed,
                    rows,
                    &mut state.noise_value,
                )?;
            }
            self.device.dflash_norm_rope_device(
                &mut state.query,
                layer.attn_q_norm.buffer(),
                rows,
                config.attention_head_count,
                config.head_dim,
                state.len,
                config.head_dim,
                config.rms_norm_eps,
                config.rope_freq_base,
            )?;
            self.device.dflash_norm_rope_device(
                &mut state.noise_key,
                layer.attn_k_norm.buffer(),
                rows,
                config.attention_head_count_kv,
                config.head_dim,
                state.len,
                config.head_dim,
                config.rms_norm_eps,
                config.rope_freq_base,
            )?;
            let layer_context_rows = if layer.sliding_window {
                context_rows.min(2_048)
            } else {
                context_rows
            };
            let context_start =
                full_context_start + context_rows.saturating_sub(layer_context_rows);
            self.device.dflash_block_attention_device(
                &state.query,
                &cache.key,
                &cache.value,
                &state.noise_key,
                &state.noise_value,
                &mut state.attention,
                rows,
                config.attention_head_count,
                config.attention_head_count_kv,
                config.head_dim,
                layer_context_rows,
                context_start,
                state.capacity,
                layer.sliding_window,
                1.0 / (config.head_dim as f32).sqrt(),
            )?;
            self.dflash_q8_prefix_matmul(
                &layer.attn_output,
                &state.attention,
                rows,
                &mut state.hidden_temp,
            )?;
            self.device
                .add_device_into(input, &state.hidden_temp, output)?;
            self.trace_dflash_buffer(
                &format!("draft_layer_{}_attention_residual", layer_index),
                output,
                rows * config.embedding_length,
            )?;
            self.device.rmsnorm_device_into(
                output,
                layer.ffn_norm.buffer(),
                rows,
                config.embedding_length,
                config.rms_norm_eps,
                &mut state.noise_normed,
            )?;
            self.trace_dflash_buffer(
                &format!("draft_layer_{}_ffn_input", layer_index),
                &state.noise_normed,
                rows * config.embedding_length,
            )?;
            let parallel_ffn = Self::dflash_parallel_projections_enabled()
                && Self::dflash_parallel_projection_supported(&layer.ffn_gate)
                && Self::dflash_parallel_projection_supported(&layer.ffn_up);
            if parallel_ffn {
                let dependency = self.device.record_event()?;
                state.projection_streams[0].wait_for_event(&dependency)?;
                self.dflash_q8_prefix_matmul_on_stream(
                    &layer.ffn_up,
                    &state.noise_normed,
                    rows,
                    &mut state.ffn_up,
                    Some(&state.projection_streams[0]),
                )?;
                self.dflash_q8_prefix_matmul(
                    &layer.ffn_gate,
                    &state.noise_normed,
                    rows,
                    &mut state.ffn_gate,
                )?;
                let completion = state.projection_streams[0].record_event()?;
                self.device.wait_for_event(&completion)?;
            } else {
                self.dflash_q8_prefix_matmul(
                    &layer.ffn_gate,
                    &state.noise_normed,
                    rows,
                    &mut state.ffn_gate,
                )?;
                self.dflash_q8_prefix_matmul(
                    &layer.ffn_up,
                    &state.noise_normed,
                    rows,
                    &mut state.ffn_up,
                )?;
            }
            self.device.silu_assign_device(&mut state.ffn_gate)?;
            self.device
                .mul_assign_device(&mut state.ffn_gate, &state.ffn_up)?;
            self.dflash_q8_prefix_matmul(
                &layer.ffn_down,
                &state.ffn_gate,
                rows,
                &mut state.hidden_temp,
            )?;
            self.device.add_assign_device(output, &state.hidden_temp)?;
            self.trace_dflash_buffer(
                &format!("draft_layer_{}_output", layer_index),
                output,
                rows * config.embedding_length,
            )?;
            input_is_a = !input_is_a;
        }
        let final_hidden = if input_is_a {
            &state.noise_a
        } else {
            &state.noise_b
        };
        self.trace_dflash_buffer(
            "final_draft_hidden",
            final_hidden,
            rows * config.embedding_length,
        )?;
        self.device.rmsnorm_device_into(
            final_hidden,
            weights.output_norm.buffer(),
            rows,
            config.embedding_length,
            config.rms_norm_eps,
            &mut state.noise_normed,
        )?;
        self.trace_dflash_buffer(
            "normalized_draft_hidden",
            &state.noise_normed,
            rows * config.embedding_length,
        )?;
        let profile = env::var_os("XRT_QWEN_DFLASH_PROFILE").is_some();
        if profile {
            self.device.synchronize()?;
        }
        let output_head_started = std::time::Instant::now();
        self.matmul_quant_verify_resident_device_into(
            &output_weights.output,
            &state.noise_normed,
            rows,
            &mut state.logits,
        )?;
        if profile {
            self.device.synchronize()?;
            tracing::warn!(
                target: "xrt_runtime::dflash",
                rows,
                vocab_size = config.vocab_size,
                elapsed_micros = output_head_started.elapsed().as_micros(),
                "DFlash output-head profile"
            );
        }
        let argmax_started = std::time::Instant::now();
        self.device.argmax_first_f32_rows_device_into(
            &state.logits,
            rows,
            config.vocab_size,
            &mut state.argmax_indices,
        )?;
        if profile {
            self.device.synchronize()?;
            tracing::warn!(
                target: "xrt_runtime::dflash",
                rows,
                vocab_size = config.vocab_size,
                elapsed_micros = argmax_started.elapsed().as_micros(),
                "DFlash argmax profile"
            );
        }
        let predictions = self
            .device
            .download_argmax_first_f32_rows(&state.argmax_indices, config.vocab_size)?;
        let take = max_draft_tokens.min(rows.saturating_sub(1));
        Ok(predictions.into_iter().skip(1).take(take).collect())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn admitted_target_layer_ids_are_stable() {
        assert_eq!(DFLASH_TARGET_LAYER_IDS, [1, 16, 31, 46, 61]);
    }
}
